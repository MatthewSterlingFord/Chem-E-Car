/****************************************************************************
 *   $Id:: IOtest.c 6097 2011-01-07 04:31:25Z nxp12832                      $
 *   Project: NXP LPC17xx GPIO example
 *
 *   Description:
 *     This file contains GPIO test modules, main entry, to test GPIO APIs.
 *
 ****************************************************************************
 * Software that is described herein is for illustrative purposes only
 * which provides customers with programming information regarding the
 * products. This software is supplied "AS IS" without any warranties.
 * NXP Semiconductors assumes no responsibility or liability for the
 * use of the software, conveys no license or title under any patent,
 * copyright, or mask work right to the product. NXP Semiconductors
 * reserves the right to make changes in the software without
 * notification. NXP Semiconductors also make no representation or
 * warranty that such application will be suitable for the specified
 * use without further testing or modification.
****************************************************************************/


#include "lpc17xx.h"
#include "lpc_types.h"
#include "adc.h"
extern volatile uint32_t ADCValue[ADC_NUM];
extern volatile uint32_t ADCIntDone;
uint32_t variable=0;

int main (void)
{
	ADCInit(ADC_CLK);
	while(1)
	{
		ADCRead( 5 );
		//other code can be done here
		while ( !ADCIntDone );
		variable = ADCValue[5];
		ADCIntDone = 0;
	}
}

