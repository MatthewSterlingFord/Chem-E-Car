/**
* This example showed the use of one flag. Flags are used for communication between two tasks. 
*/

/*---------------------------- Include ---------------------------------------*/
#include <CoOS.h>			              /*!< CoOS header file	         */
#include "LPC17xx.h"
#include "lpc_types.h"
#include "GPIO.h"

/*---------------------------- Symbol Define -------------------------------*/
#define STACK_SIZE_TASKA 128              /*!< Define "taskA" task size */
#define STACK_SIZE_TASKB 128              /*!< Define "taskA" task size */
#define STACK_SIZE_TASKC 128              /*!< Define "taskA" task size */

/*---------------------------- Variable Define -------------------------------*/
OS_STK     taskA_stk[STACK_SIZE_TASKA];	  /*!< Define "taskA" task stack */
OS_STK     taskB_stk[STACK_SIZE_TASKB];	  /*!< Define "taskB" task stack */
OS_STK     taskC_stk[STACK_SIZE_TASKC];	  /*!< Define "led" task stack   */

/*---------------------------- Flag Define -------------------------------*/
OS_FlagID flagID;     					  /*!< Define flagID as flag*/

/**
 *******************************************************************************
 * @brief       "taskA" task code
 * @param[in]   None
 * @param[out]  None
 * @retval      None
 * @par Description
 * @details    This task use to crate mutex and flags,print message "taskA running".
 *             Indicate "taskA" had been executed.
 *******************************************************************************
 */
void taskA (void* pdata) {				// This is one of the two tasks that is created in the main loop
	GPIOSetDir(1, 18, 1);				// Set PIO1_19 as output
	uint32_t flipflop = 0;				// Make a local variable and give it the value 0
	flagID = CoCreateFlag(0, 0);		// Create a flag and set it in manual reset modus
  for (;;) {							// Make a never ending loop
	  if(flipflop == 0)					// If variable is zero make variable 1 and clear the flag
	  {
		  flipflop = 1;
		  CoClearFlag(flagID);
	  }
	  else								// If variable is not zero make variable 0 and set the flag
	  {
		  flipflop = 0;
		  CoSetFlag(flagID);
	  }
	  GPIOSetValue(1, 18, flipflop);	// Set PIO1_18 HIGH or LOW
	CoTickDelay (100);					// A delay of 100 milliseconds
  }
}


/**
 *******************************************************************************
 * @brief       "taskB" task code
 * @param[in]   None
 * @param[out]  None
 * @retval      None
 * @par Description
 * @details    This task use to print message "taskB running". Indicate "taskB"
 *             had been executed.
 *******************************************************************************
 */
void taskB (void* pdata){						// This is one of the two tasks that is created in the main loop
	GPIOSetDir(1, 19, 1);						// Set PIO1_19 as output
	StatusType result;							// Create a status type variable
  for (;;)										// Make a never ending loop
  {
	  GPIOSetValue(1, 19, 0);					// Make PIO1_19 LOW
	  result = CoWaitForSingleFlag(flagID, 500);// Put the status of the flag in the variable, if the flag wasn't recieved in 500mS a timeout occurs
	  GPIOSetValue(1, 19, 1);					// Make PIO1_19 HIGH
  }
}
void myISR(void)								// This is the interrupt loop
{
      CoEnterISR();								// Start interrupt
      isr_SetFlag(flagID);                      // Set flag
      CoExitISR();								// Exit interrupt
}
/**
 *******************************************************************************
 * @brief		main function
 * @param[in] 	None
 * @param[out] 	None
 * @retval		None
 *******************************************************************************
 */
int main (){   				// The main loop

  CoInitOS ();				 /*!< Initial CooCox CoOS          */

  /*!< Create two tasks	*/
  CoCreateTask (taskA,0,0,&taskA_stk[STACK_SIZE_TASKA-1],STACK_SIZE_TASKA);
  CoCreateTask (taskB,0,1,&taskB_stk[STACK_SIZE_TASKB-1],STACK_SIZE_TASKB);
  CoStartOS ();			    /*!< Start multitask	           */

  while (1);                /*!< The code don't reach here	   */
}

