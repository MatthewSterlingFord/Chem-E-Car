/**
* This example showed the use of multiple flags. Flags are used for communication between two tasks. 
*/
/*---------------------------- Include ---------------------------------------*/
#include <CoOS.h>			              /*!< CoOS header file	         */
#include "LPC17xx.h"
#include "lpc_types.h"
#include "GPIO.h"

/*---------------------------- Symbol Define -------------------------------*/
#define STACK_SIZE_TASKA 128              /*!< Define "taskA" task size */
#define STACK_SIZE_TASKB 128              /*!< Define "taskA" task size */
#define STACK_SIZE_TASKC 128              /*!< Define "taskA" task size */

/*---------------------------- Variable Define -------------------------------*/
OS_STK     taskA_stk[STACK_SIZE_TASKA];	  /*!< Define "taskA" task stack */
OS_STK     taskB_stk[STACK_SIZE_TASKB];	  /*!< Define "taskB" task stack */
OS_STK     taskC_stk[STACK_SIZE_TASKC];	  /*!< Define "led" task stack   */

/*---------------------------- Flag Define -------------------------------*/
OS_FlagID flagID1;						  /*!< Define flagID1 as flagID */
OS_FlagID flagID2;						  /*!< Define flagID2 as flagID */
OS_FlagID flagID3;						  /*!< Define flagID3 as flagID */

/**
 *******************************************************************************
 * @brief       "taskA" task code
 * @param[in]   None
 * @param[out]  None
 * @retval      None
 * @par Description
 * @details    This task use to crate mutex and flags,print message "taskA running".
 *             Indicate "taskA" had been executed.
 *******************************************************************************
 */
void taskA (void* pdata) { 								// This is one of the two created tasks

	 uint32_t flag;										// Create a variable
	 StatusType err;									// Create a status type variable

	 flagID1 = CoCreateFlag(0,0);						// Reset manually, the original state is not-ready
	 flagID2 = CoCreateFlag(0,0);    					// Reset manually, the original state is not-ready
	 flagID3 = CoCreateFlag(0,0);    					// Reset manually, the original state is not-ready
	 flag = flagID1 | flagID2 | flagID3;				// variable flag is flagID1, flagID2 or flagID3

  for (;;)												// Make a never ending loop
  {
	 CoWaitForMultipleFlags(flag,OPT_WAIT_ANY,0,&err); 	// Wait for the flags to be set
  }
}


/**
 *******************************************************************************
 * @brief       "taskB" task code
 * @param[in]   None
 * @param[out]  None
 * @retval      None
 * @par Description
 * @details    This task use to print message "taskB running". Indicate "taskB"
 *             had been executed.
 *******************************************************************************
 */
void taskB (void* pdata){ 								// This is one of the two created tasks

  for (;;) 								   				// Create a never ending loop
  {
	 CoSetFlag(flagID1);								// Set flagID1
  }
}
void myISR(void)										// This is the interrupt loop
{
	 CoEnterISR();										// Enter interrupt
     isr_SetFlag(flagID2);								// Set flagID2
     CoExitISR();										// Exit interrupt
}
/**
 *******************************************************************************
 * @brief		main function
 * @param[in] 	None
 * @param[out] 	None
 * @retval		None
 *******************************************************************************
 */
int main (){

  CoInitOS ();				 /*!< Initial CooCox CoOS          */

  /*!< Create three tasks	*/
  CoCreateTask (taskA,0,0,&taskA_stk[STACK_SIZE_TASKA-1],STACK_SIZE_TASKA);
  CoCreateTask (taskB,0,1,&taskB_stk[STACK_SIZE_TASKB-1],STACK_SIZE_TASKB);
  CoStartOS ();			    /*!< Start multitask	           */

  while (1);                /*!< The code don''t reach here	   */
}

