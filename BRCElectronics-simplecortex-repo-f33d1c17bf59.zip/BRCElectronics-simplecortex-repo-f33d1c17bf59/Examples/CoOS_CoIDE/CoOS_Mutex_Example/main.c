/**
 * This example illustrates the use of a mutex. Everything that is in a mutex has a high priority.
 * mutex forbids multiple tasks to enter the critical code section at the same time. Therefore, only one task can enter it at any time.
*/
/*---------------------------- Include ---------------------------------------*/

#include <CoOS.h>			              /*!< CoOS header file	         */
#include "LPC17xx.h"
#include "lpc_types.h"
#include "GPIO.h"


/*---------------------------- Symbol Define -------------------------------*/
#define STACK_SIZE_TASKA 128              /*!< Define "taskA" task size */
#define STACK_SIZE_TASKB 128              /*!< Define "taskA" task size */
#define STACK_SIZE_TASKC 128              /*!< Define "taskA" task size */

/*---------------------------- Variable Define -------------------------------*/
OS_STK     taskA_stk[STACK_SIZE_TASKA];	  /*!< Define "taskA" task stack */
OS_STK     taskB_stk[STACK_SIZE_TASKB];	  /*!< Define "taskB" task stack */
OS_STK     taskC_stk[STACK_SIZE_TASKC];	  /*!< Define "led" task stack   */

OS_MutexID mutexID;						  /*!< Define mutexID as a MutexID */

/**
 *******************************************************************************
 * @brief       "taskA" task code
 * @param[in]   None
 * @param[out]  None
 * @retval      None
 * @par Description
 *******************************************************************************
 */
 
void taskA (void* pdata) {				// This is one of the three created tasks

	GPIOSetDir(1, 25, 1);				// Set PIO1_25 as output
	GPIOSetDir(1, 18, 1);				// Set PIO1_18 as output
	uint32_t flipflop = 0;				// Create a local variable
	
	for (;;) {							// Make a never ending loop
  	  mutexID = CoCreateMutex ( );		// Create a mutex section
      CoEnterMutexSection(mutexID );  	// Enter the mutex section
      CoTickDelay (5);					// Delay of 5 milliseconds
      GPIOSetValue(1, 25, 0);    		// Critical codes
      CoTickDelay (5);					// Delay of 5 milliseconds
      GPIOSetValue(1, 25, 1);    		// Critical codes
      CoLeaveMutexSection(mutexID );  	// Leave the mutex section
	  
	  if(flipflop == 0)					// If variable is zero make variable 1
	  {
		  flipflop = 1;
	  }
	  else								// If variable is not zero make variable 0
	  {
		  flipflop = 0;
	  }
    GPIOSetValue(1, 18, flipflop);		// Set PIO1_18 HIGH or LOW
	CoTickDelay (100);					// Delay of 100 milliseconds
  }
}


/**
 *******************************************************************************
 * @brief       "taskB" task code
 * @param[in]   None
 * @param[out]  None
 * @retval      None
 * @par Description
 *******************************************************************************
 */
void taskB (void* pdata){				// This is one of the three created tasks

	GPIOSetDir(1, 19, 1);				// Set PIO1_25 as output
	uint32_t flipflop = 0;				// Create a local variable
	
	for (;;) {							// Make a never ending loop
	  if(flipflop == 0)					// If variable is zero make variable 1
	  {
		  flipflop = 1;
	  }
	  else								// If variable is not zero make variable 0
	  {
		  flipflop = 0;
	  }
	  
    GPIOSetValue(1, 19, flipflop);		// Set PIO1_19 HIGH or LOW
	CoTickDelay (200);					// Delay of 200 milliseconds
  }
}


/**
 *******************************************************************************
 * @brief       "led" task code
 * @param[in]   None
 * @param[out]  None
 * @retval      None
 * @par Description
 *******************************************************************************
 */
void taskC (void* pdata){				// This is one of the three created tasks

	GPIOSetDir(1, 24, 1);				// Set PIO1_25 as output
	uint32_t flipflop = 0;				// Create a local variable
	
	for (;;) {							// Make a never ending loop
	  if(flipflop == 0)					// If variable is zero make variable 1
	  {
		  flipflop = 1;
	  }
	  else								// If variable is not zero make variable 0
	  {
		  flipflop = 0;
	  }

	GPIOSetValue(1, 24, flipflop);		// Set PIO1_24 HIGH or LOW
	CoTickDelay (75);					// Delay of 75 milliseconds
  }
}


/**
 *******************************************************************************
 * @brief		main function
 * @param[in] 	None
 * @param[out] 	None
 * @retval		None
 *******************************************************************************
 */
int main (){

  CoInitOS ();				 /*!< Initial CooCox CoOS          */

  /*!< Create three new tasks	*/
  CoCreateTask (taskA,0,0,&taskA_stk[STACK_SIZE_TASKA-1],STACK_SIZE_TASKA);
  CoCreateTask (taskB,0,1,&taskB_stk[STACK_SIZE_TASKB-1],STACK_SIZE_TASKB);
  CoCreateTask (taskC,0,2,&taskC_stk[STACK_SIZE_TASKC-1],STACK_SIZE_TASKC);
  CoStartOS ();			    /*!< Start multitasking	           */

  while (1);                /*!< The code can't reach here	   */
}

