/* This program demonstrates a use of (HD44780) 16x2 Character Display on SimpleCortex board.
 * The LCD is used in 4 bit configuration and following are the hardware connections.
 * ---LCD---	--SimpleCortex--
 * 	(2)VCC			5V
 * 	(1)GND			gnd
 * 	(4)RS			p2.3
 * 	(5)RW			p2.4
 * 	(6)EN			p2.5
 * 	(11)DB4			p0.4
 * 	(12)DB5			p0.5
 * 	(13)DB6			p0.6
 * 	(14)DB7			p0.7
 * @ Author: Heitor Mercaldi
 * @ Date Aug. 2012
 * @ Version 1.0
*/
#include "LPC17xx.h"
#include "lpc_types.h"
#include "lcd44780.h"
#include "timer.h"

int main(void)
{
	SystemInit();                         /* initialize clocks */
	init_lcd();
	TimerInit(0, 1000);

  	lcd_putstring(0,"SimpleCortex 1.3");
  	lcd_putstring(1," LPC1769  (nxp) ");

    while(1)
    {
    }
}
