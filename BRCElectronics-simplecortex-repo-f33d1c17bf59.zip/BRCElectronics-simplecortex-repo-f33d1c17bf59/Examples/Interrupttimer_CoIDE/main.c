#include "LPC17xx.h"
#include "lpc_types.h"
#include "GPIO.h"
#include "timer.h"

uint32_t toggle = 0;
uint32_t toggle1 = 0;
uint32_t toggle2 = 0;
uint32_t toggle3 = 0;

int main(void)
{
	init_timer(0, 15000000);
	init_timer(1, 30000000);
	init_timer(2, 60000000);
	init_timer(3, 120000000);
	enable_timer(0);
	enable_timer(1);
	enable_timer(2);
	enable_timer(3);
	GPIOSetDir(0, 20, 1);
	GPIOSetDir(0, 19, 1);
	GPIOSetDir(0, 11, 1);
	GPIOSetDir(0, 10, 1);
    while(1)
    {
    }
}

void TIMER0_IRQHandler (void)
{
TIMER0_interrupt();
toggle = ~toggle;
GPIOSetValue(0, 20, toggle);
}

void TIMER1_IRQHandler (void)
{
TIMER1_interrupt();
toggle1 = ~toggle1;
GPIOSetValue(0, 19, toggle1);
}

void TIMER2_IRQHandler (void)
{
TIMER2_interrupt();
toggle2 = ~toggle2;
GPIOSetValue(0, 11, toggle2);
}

void TIMER3_IRQHandler (void)
{
TIMER3_interrupt();
toggle3 = ~toggle3;
GPIOSetValue(0, 10, toggle3);
}
