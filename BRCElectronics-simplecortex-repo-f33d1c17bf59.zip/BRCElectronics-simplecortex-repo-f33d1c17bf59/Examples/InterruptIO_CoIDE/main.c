#include "LPC17xx.h"
#include "lpc_types.h"
#include "GPIO.h"
#include "timer.h"

uint32_t checkvalue;

int main(void)
{
	GPIOSetPull(0, 25, 2);
	GPIOSetPull(0, 26, 2);
	GPIOSetInterrupt(0, 25, 1);
	GPIOSetInterrupt(0, 26, 1);
	GPIOSetDir(0, 10, 1);

    while(1)
    {
    }
}

void EINT3_IRQHandler (void)
{
	checkvalue = GPIOCheckInterrupts(0, 1);
	if (checkvalue == (1 << 25))
	{
		GPIOSetValue(0, 10, 1);
	}
	else if (checkvalue == (1 << 26))
	{
		GPIOSetValue(0, 10, 0);
	}
	GPIOClearInterrupt();
}
