#include <string.h>
#include "drawing.h"

void drawCharBitmap(const uint16_t xPixel, const uint16_t yPixel, uint16_t color, const uint8_t *glyph, uint8_t glyphHeightPages, uint8_t glyphWidthBits)
{
  uint16_t verticalPage, horizBit, currentY, currentX;
  uint16_t indexIntoGlyph;

  // set initial current y
  currentY = yPixel;
  currentX = xPixel;

  // for each page of the glyph
  for (verticalPage = glyphHeightPages; verticalPage > 0; --verticalPage)
  {
    // for each horizontol bit
    for (horizBit = 0; horizBit < glyphWidthBits; ++horizBit)
    {
      // next byte
      indexIntoGlyph = (glyphHeightPages * horizBit) + verticalPage - 1;

      currentX = xPixel + (horizBit);
      // send the data byte
      if (glyph[indexIntoGlyph] & (0X80)) drawPixel(currentX, currentY, color);
      if (glyph[indexIntoGlyph] & (0X40)) drawPixel(currentX, currentY - 1, color);
      if (glyph[indexIntoGlyph] & (0X20)) drawPixel(currentX, currentY - 2, color);
      if (glyph[indexIntoGlyph] & (0X10)) drawPixel(currentX, currentY - 3, color);
      if (glyph[indexIntoGlyph] & (0X08)) drawPixel(currentX, currentY - 4, color);
      if (glyph[indexIntoGlyph] & (0X04)) drawPixel(currentX, currentY - 5, color);
      if (glyph[indexIntoGlyph] & (0X02)) drawPixel(currentX, currentY - 6, color);
      if (glyph[indexIntoGlyph] & (0X01)) drawPixel(currentX, currentY - 7, color);
    }
    // next line of pages
    currentY += 8;
  }
}

void drawCirclePoints(int cx, int cy, int x, int y, uint16_t color)
{
  if (x == 0)
  {
	  lcdDrawPixel(cx, cy + y, color);
	  lcdDrawPixel(cx, cy - y, color);
	  lcdDrawPixel(cx + y, cy, color);
	  lcdDrawPixel(cx - y, cy, color);
  }
  else if (x == y)
  {
	  lcdDrawPixel(cx + x, cy + y, color);
	  lcdDrawPixel(cx - x, cy + y, color);
	  lcdDrawPixel(cx + x, cy - y, color);
	  lcdDrawPixel(cx - x, cy - y, color);
  }
  else if (x < y)
  {
	  lcdDrawPixel(cx + x, cy + y, color);
	  lcdDrawPixel(cx - x, cy + y, color);
	  lcdDrawPixel(cx + x, cy - y, color);
	  lcdDrawPixel(cx - x, cy - y, color);
	  lcdDrawPixel(cx + y, cy + x, color);
	  lcdDrawPixel(cx - y, cy + x, color);
	  lcdDrawPixel(cx + y, cy - x, color);
	  lcdDrawPixel(cx - y, cy - x, color);
  }
}

void drawPixel(uint16_t x, uint16_t y, uint16_t color)
{
  lcdDrawPixel(x, y, color);
}

void drawFill(uint16_t color)
{
  lcdFillRGB(color);
}

void drawTestPattern(void)
{
  lcdTest();
}

void drawString(uint16_t x, uint16_t y, uint16_t color, const FONT_INFO *fontInfo, char *str)
{
  uint16_t currentX, charWidth, characterToOutput;
  const FONT_CHAR_INFO *charInfo;
  uint16_t charOffset;

  // set current x, y to that of requested
  currentX = x;

  // while not NULL
  while (*str != '\0')
  {
    // get character to output
    characterToOutput = *str;

    // get char info
    charInfo = fontInfo->charInfo;

    // some fonts have character descriptors, some don't
    if (charInfo != NULL)
    {
      // get correct char offset
      charInfo += (characterToOutput - fontInfo->startChar);

      // get width from char info
      charWidth = charInfo->widthBits;

      // get offset from char info
      charOffset = charInfo->offset;
    }
    else
    {
      // if no char info, char width is always 5
      charWidth = 5;

      // char offset - assume 5 * letter offset
      charOffset = (characterToOutput - fontInfo->startChar) * 5;
    }

    // Send individual characters
    drawCharBitmap(currentX, y + 1, color, &fontInfo->data[charOffset], fontInfo->heightPages, charWidth);

    // next char X
    currentX += charWidth + 1;

    // next char
    str++;
  }
}

uint16_t drawGetStringWidth(const FONT_INFO *fontInfo, char *str)
{
  uint16_t width = 0;
  uint32_t currChar;
  uint32_t startChar = fontInfo->startChar;

  // until termination
  for (currChar = *str; currChar; currChar = *(++str))
  {
    // if char info exists for the font, use width from there
    if (fontInfo->charInfo != NULL)
    {
      width += fontInfo->charInfo[currChar - startChar].widthBits + 1;
    }
    else
    {
      width += 5 + 1;
    }
  }

  /* return the wdith */
  return width;
}

void drawLine ( uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint16_t color )
{
  // Check if we can used the optimised horizontal line method
  if (y0 == y1)
  {
    lcdDrawHLine(x0, x1, y0, color);
    return;
  }

  // ToDo: This is currently buggy ... fix it

  //  if (x0 == x1)
  //  {
  //    // ToDo: This may actually be slower than drawing individual pixels on
  //    // short lines ... Set a minimum line size to use the 'optimised' method
  //    // (which changes the screen orientation) ?
  //    lcdDrawVLine(x0, y0, y1, color);
  //    return;
  //  }

  // Draw non horizontal line
  int dy = y1 - y0;
  int dx = x1 - x0;
  int stepx, stepy;

  if (dy < 0) { dy = -dy;  stepy = -1; } else { stepy = 1; }
  if (dx < 0) { dx = -dx;  stepx = -1; } else { stepx = 1; }
  dy <<= 1;                               // dy is now 2*dy
  dx <<= 1;                               // dx is now 2*dx

  drawPixel(x0, y0, color);
  if (dx > dy)
  {
    int fraction = dy - (dx >> 1);        // same as 2*dy - dx
    while (x0 != x1)
    {
      if (fraction >= 0)
      {
        y0 += stepy;
        fraction -= dx;                   // same as fraction -= 2*dx
      }
      x0 += stepx;
      fraction += dy;                     // same as fraction -= 2*dy
      drawPixel(x0, y0, color);
    }
  }
  else
  {
    int fraction = dx - (dy >> 1);
    while (y0 != y1)
    {
      if (fraction >= 0)
      {
        x0 += stepx;
        fraction -= dy;
      }
      y0 += stepy;
      fraction += dx;
      drawPixel(x0, y0, color);
    }
  }
}

void drawCircle (uint16_t xCenter, uint16_t yCenter, uint16_t radius, uint16_t color)
{
  int x = 0;
  int y = radius;
  int p = (5 - radius*4)/4;

  drawCirclePoints(xCenter, yCenter, x, y, color);
  while (x < y)
  {
    x++;
    if (p < 0)
    {
      p += 2*x+1;
    }
    else
    {
      y--;
      p += 2*(x-y)+1;
    }
    drawCirclePoints(xCenter, yCenter, x, y, color);
  }
}

void drawCircleFilled (uint16_t xCenter, uint16_t yCenter, uint16_t radius, uint16_t color)
{
  int16_t f = 1 - radius;
  int16_t ddF_x = 1;
  int16_t ddF_y = -2 * radius;
  int16_t x = 0;
  int16_t y = radius;

  drawLine(xCenter, yCenter-radius, xCenter, (yCenter-radius) + (2*radius), color);

  while (x<y)
  {
    if (f >= 0)
    {
      y--;
      ddF_y += 2;
      f += ddF_y;
    }
    x++;
    ddF_x += 2;
    f += ddF_x;

    // ToDo: This will cause pixel flooding if radius is bigger than
    // screen dimenstions (due to integer value overflow)!
    drawLine(xCenter+x, yCenter-y, xCenter+x, (yCenter-y) + (2*y), color);
    drawLine(xCenter-x, yCenter-y, xCenter-x, (yCenter-y) + (2*y), color);
    drawLine(xCenter+y, yCenter-x, xCenter+y, (yCenter-x) + (2*x), color);
    drawLine(xCenter-y, yCenter-x, xCenter-y, (yCenter-x) + (2*x), color);
  }
}

void drawRectangle ( uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint16_t color)
{
  uint16_t x, y;

  if (y1 < y0)
  {
    // Swich y1 and y0
    y = y1;
    y1 = y0;
    y0 = y;
  }

  if (x1 < x0)
  {
    // Swich x1 and x0
    x = x1;
    x1 = x0;
    x0 = x;
  }

  drawLine (x0, y0, x1, y0, color);
  drawLine (x1, y0, x1, y1, color);
  drawLine (x1, y1, x0, y1, color);
  drawLine (x0, y1, x0, y0, color);
}

void drawRectangleFilled ( uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint16_t color)
{
  int height;
  uint16_t x, y;

  if (y1 < y0)
  {
    // Switch y1 and y0
    y = y1;
    y1 = y0;
    y0 = y;
  }

  if (x1 < x0)
  {
    // Switch x1 and x0
    x = x1;
    x1 = x0;
    x0 = x;
  }

  height = y1 - y0;
  for (height = y0; y1 > height - 1; ++height)
  {
    drawLine(x0, height, x1, height, color);
  }
}

uint16_t drawRGB24toRGB565(uint8_t r, uint8_t g, uint8_t b)
{
	uint16_t value;
	value = ((r / 8) << 11) | ((g / 4) << 5) | (b / 8);
	return value;
}

uint32_t drawRGB565toBGRA32(uint16_t color)
{
  uint32_t bits = (uint32_t)color;
  uint32_t blue = bits & 0x001F;     // 5 bits blue
  uint32_t green = bits & 0x07E0;    // 6 bits green
  uint32_t red = bits & 0xF800;      // 5 bits red

  // Return shifted bits with alpha set to 0xFF
  return (red << 8) | (green << 5) | (blue << 3) | 0xFF000000;
}

uint16_t drawBGR2RGB(uint16_t color)
{
  uint16_t r, g, b;

  b = (color>>0)  & 0x1f;
  g = (color>>5)  & 0x3f;
  r = (color>>11) & 0x1f;

  return( (b<<11) + (g<<5) + (r<<0) );
}

void drawProgressBar ( uint16_t x, uint16_t y, uint16_t width, uint16_t height, uint16_t barBorderColor, uint16_t barFillColor, uint8_t progress )
{
  // Note: Color definitions are contained in 'colors.h'
  uint16_t bg1, bg2,  border;

  // Set colors
  bg1       = COLOR_PROGRESSBAR_BACKGROUND1;
  bg2       = COLOR_PROGRESSBAR_BACKGROUND2;
  border    = COLOR_PROGRESSBAR_BORDER;

  // Draw border with rounded corners
  drawLine(x+2, y, x + width - 2, y, border);
  drawLine(x + width, y + 2, x + width, y + height - 2, border);
  drawLine(x + width - 2, y + height, x + 2, y + height, border);
  drawLine(x, y + height - 2, x, y + 2, border);
  drawPixel(x + 1, y + 1, border);
  drawPixel(x + width - 1, y + 1, border);
  drawPixel(x + 1, y + height - 1, border);
  drawPixel(x + width - 1, y + height - 1, border);

  // Fill outer container
  drawLine(x+1, y+2, x+1, y+height-2, bg1);
  drawLine(x+2, y+height-1, x+width-2, y+height-1, bg2);
  drawLine(x+width-1, y+height-2, x+width-1, y+2, bg1);
  drawLine(x+width-2, y+1, x+2, y+1, bg1);
  drawRectangleFilled(x+2, y+2, x+width-2, y+height-2, bg1);
  drawRectangleFilled(x+2, y+(height/2), x+width-2, y+height-2, bg2);

  // Progress bar
  if (progress > 0 && progress <= 100)
  {
    // Calculate bar size
    uint16_t bw;
    bw = (width - 6);   // bar at 100%
    if (progress != 100)
    {
      bw = (bw * progress) / 100;
    }
    drawRectangle(x + 3, y + 3, bw + x + 3, y + height - 3, barBorderColor);
    drawRectangleFilled(x + 4, y + 4, bw + x + 3 - 1, y + height - 4, barFillColor);
  }
}

void drawButton(uint16_t x, uint16_t y, uint16_t width, uint16_t height, const FONT_INFO *fontInfo, uint16_t fontHeight, char* text, bool pressed)
{
  // Note: Color definitions are contained in 'colors.h'
  uint16_t bgactive1, bg1, bgactive2, bg2, border, highlight, highlightdarker, font, fontactive;

  // Set colors
  bgactive1       = COLOR_BUTTON_BACKGROUNDACTIVE1;
  bg1             = COLOR_BUTTON_BACKGROUND1;
  bgactive2       = COLOR_BUTTON_BACKGROUNDACTIVE2;
  bg2             = COLOR_BUTTON_BACKGROUND2;
  border          = COLOR_BUTTON_BORDER;
  highlight       = COLOR_BUTTON_HIGHLIGHT;
  highlightdarker = COLOR_BUTTON_HIGHLIGHTDARKER;
  font            = COLOR_BUTTON_FONT;
  fontactive      = COLOR_BUTTON_FONTACTIVE;

  // Draw background
  drawRectangleFilled(x + 1, y + 1, x + width - 1, y + height - 1, pressed ? bgactive1 : bg1);
  drawRectangleFilled(x + 1, y + (height / 2), x + width - 1, y + height - 1, pressed ? bgactive2 : bg2);

  // Draw outer border
  drawLine(x + 2, y, x + width - 2, y, border);
  drawLine(x, y + 2, x, y + height - 2, border);
  drawLine(x + 2, y + height, x + width - 2, y + height, border);
  drawLine(x + width, y + height - 2, x + width, y + 2, border);
  drawPixel(x + 1, y + 1, border);
  drawPixel(x + width - 1, y + 1, border);
  drawPixel(x + 1, y + height - 1, border);
  drawPixel(x + width - 1, y + height - 1, border);

  // Draw highlights
  drawLine(x + 2, y + 1, x + width - 2, y + 1, highlight);
  drawLine(x + width - 1, y + 2, x + width - 1, y + height - 2, highlight);
  drawLine(x + 1, y + 2, x + 1, y + height - 2, highlightdarker);
  drawLine(x + 2, y + height - 1, x + width - 2, y + height - 1, highlightdarker);

  // Render text
  if (text != NULL)
  {
    uint16_t textWidth = drawGetStringWidth(&*fontInfo, text);
    uint16_t xStart = x + (width / 2) - (textWidth / 2);
    uint16_t yStart = y + (height / 2) - (fontHeight / 2) + 1;
    drawString(xStart, yStart, pressed ? fontactive : font, &*fontInfo, text);
  }
}

char* itoa(int value, char* result, int base)
{
	// check that the base if valid
	if (base < 2 || base > 36) { *result = '\0'; return result; }

	char* ptr = result, *ptr1 = result, tmp_char;
	int tmp_value;

	do {
		tmp_value = value;
		value /= base;
		*ptr++ = "zyxwvutsrqponmlkjihgfedcba9876543210123456789abcdefghijklmnopqrstuvwxyz" [35 + (tmp_value - value * base)];
	} while ( value );

	// Apply negative sign
	if (tmp_value < 0) *ptr++ = '-';
	*ptr-- = '\0';
	while(ptr1 < ptr) {
		tmp_char = *ptr;
		*ptr--= *ptr1;
		*ptr1++ = tmp_char;
	}
	return result;
}

bmp_error_t drawBitmapImage(uint16_t x, uint16_t y, char *filename)
{
  return bmpDrawBitmap(x, y, filename);
}
