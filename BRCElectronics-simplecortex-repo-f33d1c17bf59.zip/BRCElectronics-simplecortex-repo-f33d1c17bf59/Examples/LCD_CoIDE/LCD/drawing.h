#include "lcd.h"
#include "colors.h"
#include "lpc_types.h"
#include "bitmapfonts.h"
#include "bmp.h"

void drawCharBitmap(const uint16_t xPixel, const uint16_t yPixel, uint16_t color, const uint8_t *glyph, uint8_t glyphHeightPages, uint8_t glyphWidthBits);
void drawCirclePoints(int cx, int cy, int x, int y, uint16_t color);
void drawPixel(uint16_t x, uint16_t y, uint16_t color);
void drawFill(uint16_t color);
void drawTestPattern(void);
void drawString(uint16_t x, uint16_t y, uint16_t color, const FONT_INFO *fontInfo, char *str);
uint16_t drawGetStringWidth(const FONT_INFO *fontInfo, char *str);
void drawLine ( uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint16_t color );
void drawCircle (uint16_t xCenter, uint16_t yCenter, uint16_t radius, uint16_t color);
void drawCircleFilled (uint16_t xCenter, uint16_t yCenter, uint16_t radius, uint16_t color);
void drawRectangle ( uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint16_t color);
void drawRectangleFilled ( uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint16_t color);
uint16_t drawRGB24toRGB565(uint8_t r, uint8_t g, uint8_t b);
uint32_t drawRGB565toBGRA32(uint16_t color);
uint16_t drawBGR2RGB(uint16_t color);
void drawProgressBar ( uint16_t x, uint16_t y, uint16_t width, uint16_t height, uint16_t barBorderColor, uint16_t barFillColor, uint8_t progress );
void drawButton(uint16_t x, uint16_t y, uint16_t width, uint16_t height, const FONT_INFO *fontInfo, uint16_t fontHeight, char* text, bool pressed);
bmp_error_t drawBitmapImage(uint16_t x, uint16_t y, char *filename);
char* itoa(int value, char* result, int base);
