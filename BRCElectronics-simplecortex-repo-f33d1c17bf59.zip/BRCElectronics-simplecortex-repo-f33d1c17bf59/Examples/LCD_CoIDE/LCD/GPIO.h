
extern void GPIOSetDir( uint32_t portNum, uint32_t bitPosi, uint32_t dir );
extern void GPIOSetValue( uint32_t portNum, uint32_t bitPosi, uint32_t bitVal );
extern void GPIOSetPull(uint32_t portNum, uint32_t bitPosi, uint32_t dir);
extern uint32_t GPIOGetValue (uint32_t portNum, uint32_t bitPosi);
void GPIOSetInterrupt (  uint32_t portNum, uint32_t bitPosi, uint32_t dir );
void GPIOClearInterrupt( void );
uint32_t GPIOCheckInterrupts ( uint32_t portNum, uint32_t dir);

#define  NoPull  	0
#define  PullUp  	1
#define  PullDown  	2

#define  Input 		0
#define  Output 	1

#define  Falling	0
#define  Rising  	1

#define  Low		0
#define  High		1
