#ifndef FF_TEST_TERM_H_
#define FF_TEST_TERM_H_

void ff_test_term_timer_callback(void); //  __attribute__ ((section(".ramfunc")));
int ff_test_term(void);

#endif

