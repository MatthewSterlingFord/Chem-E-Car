void handleethernet(void);
void initethernet (void);

#define MYIP_1	192
#define MYIP_2	168
#define MYIP_3	1
#define MYIP_4	5
#define BUF ((struct uip_eth_hdr *)&uip_buf[0])
