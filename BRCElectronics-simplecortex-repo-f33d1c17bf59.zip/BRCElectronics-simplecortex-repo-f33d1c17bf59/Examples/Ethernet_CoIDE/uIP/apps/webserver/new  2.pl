     #!/usr/bin/perl
    use strict;
    use warnings;
    my $filename = 'httpd-fsdata2.h';
    my $find = ', };';
    my $replace = ' };';
    {
       local @ARGV = ($filename);
       local $^I = '.bac';
       while( <> ){
          if( s/$find/$replace/ig ) {
             print;
          }
          else {
             print;
          }
       }
    }
    print "Finished";
	
	