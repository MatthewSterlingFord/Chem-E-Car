class GPIO
{
public:
	GPIO();
	void On(uint32_t portNum, uint32_t bitPosi);
	void Off(uint32_t portNum, uint32_t bitPosi);
	void Input(uint32_t portNum, uint32_t bitPosi);
	void Output(uint32_t portNum, uint32_t bitPosi);
	void Pullup(uint32_t portNum, uint32_t bitPosi);
	void Pulldown(uint32_t portNum, uint32_t bitPosi);
	void Pullnon(uint32_t portNum, uint32_t bitPosi);
	uint32_t Read(uint32_t portNum, uint32_t bitPosi);
};
