#include "lpc17xx.h"
#include "lpc_types.h"
#include "gpio.h"
static LPC_GPIO_TypeDef (* const LPC_GPIO[5]) = { LPC_GPIO0, LPC_GPIO1, LPC_GPIO2, LPC_GPIO3, LPC_GPIO4  };

uint32_t portNumber;
uint32_t bitPosition;

GPIO::GPIO()
{
}

void GPIO::On(uint32_t portNum, uint32_t bitPosi)
{
	LPC_GPIO[portNum]->FIOMASK = ~(1<<bitPosi);
	LPC_GPIO[portNum]->FIOSET = (1<<bitPosi);
}

void GPIO::Off(uint32_t portNum, uint32_t bitPosi)
{
	LPC_GPIO[portNum]->FIOMASK = ~(1<<bitPosi);
	LPC_GPIO[portNum]->FIOCLR = (1<<bitPosi);
}

void GPIO::Input(uint32_t portNum, uint32_t bitPosi)
{
	LPC_GPIO[portNum]->FIODIR &= ~(1<<bitPosi);
}

void GPIO::Output(uint32_t portNum, uint32_t bitPosi)
{
	LPC_GPIO[portNum]->FIODIR |= 1<<bitPosi;
}

void GPIO::Pullup(uint32_t portNum, uint32_t bitPosi)
{

	uint32_t dir = 00;   //pulldown resistor

	switch (portNum)
	{
		case 0:

			if (bitPosi < 16 ) {
				bitPosi = bitPosi * 2;
				LPC_PINCON->PINMODE0 = dir<<bitPosi;
			} else if (bitPosi > 15){
				bitPosi = bitPosi - 16;
				bitPosi = bitPosi * 2;
				LPC_PINCON->PINMODE1 = dir<<bitPosi;
			}

		break;

		case 1:

			if (bitPosi < 16 ) {
				bitPosi = bitPosi * 2;
				LPC_PINCON->PINMODE2 = dir<<bitPosi;
			} else if (bitPosi > 15){
				bitPosi = bitPosi - 16;
				bitPosi = bitPosi * 2;
				LPC_PINCON->PINMODE3 = dir<<bitPosi;
			}

		break;

		case 2:

			if (bitPosi < 14 ) {
				bitPosi = bitPosi * 2;
				LPC_PINCON->PINMODE4 = dir<<bitPosi;
			}

		break;

		case 3:

			if (bitPosi == 25){
				LPC_PINCON->PINMODE7 = dir<<18;
			}else if (bitPosi == 26){
				LPC_PINCON->PINMODE7 = dir<<20;
			}

		break;

		case 4:
			if (bitPosi == 28){
				LPC_PINCON->PINMODE9 = dir<<24;
			}else if (bitPosi == 29){
				LPC_PINCON->PINMODE9 = dir<<26;
			}

	}
}

void GPIO::Pulldown(uint32_t portNum, uint32_t bitPosi)
{

	uint32_t dir = 11;   //pulldown resistor

	switch (portNum)
	{
		case 0:

			if (bitPosi < 16 ) {
				bitPosi = bitPosi * 2;
				LPC_PINCON->PINMODE0 = dir<<bitPosi;
			} else if (bitPosi > 15){
				bitPosi = bitPosi - 16;
				bitPosi = bitPosi * 2;
				LPC_PINCON->PINMODE1 = dir<<bitPosi;
			}

		break;

		case 1:

			if (bitPosi < 16 ) {
				bitPosi = bitPosi * 2;
				LPC_PINCON->PINMODE2 = dir<<bitPosi;
			} else if (bitPosi > 15){
				bitPosi = bitPosi - 16;
				bitPosi = bitPosi * 2;
				LPC_PINCON->PINMODE3 = dir<<bitPosi;
			}

		break;

		case 2:

			if (bitPosi < 14 ) {
				bitPosi = bitPosi * 2;
				LPC_PINCON->PINMODE4 = dir<<bitPosi;
			}

		break;

		case 3:

			if (bitPosi == 25){
				LPC_PINCON->PINMODE7 = dir<<18;
			}else if (bitPosi == 26){
				LPC_PINCON->PINMODE7 = dir<<20;
			}

		break;

		case 4:
			if (bitPosi == 28){
				LPC_PINCON->PINMODE9 = dir<<24;
			}else if (bitPosi == 29){
				LPC_PINCON->PINMODE9 = dir<<26;
			}

	}
}

void GPIO::Pullnon(uint32_t portNum, uint32_t bitPosi)
{

	uint32_t dir = 10; //no pull up/down resistor

	switch (portNum)
	{
		case 0:

			if (bitPosi < 16 ) {
				bitPosi = bitPosi * 2;
				LPC_PINCON->PINMODE0 = dir<<bitPosi;
			} else if (bitPosi > 15){
				bitPosi = bitPosi - 16;
				bitPosi = bitPosi * 2;
				LPC_PINCON->PINMODE1 = dir<<bitPosi;
			}

		break;

		case 1:

			if (bitPosi < 16 ) {
				bitPosi = bitPosi * 2;
				LPC_PINCON->PINMODE2 = dir<<bitPosi;
			} else if (bitPosi > 15){
				bitPosi = bitPosi - 16;
				bitPosi = bitPosi * 2;
				LPC_PINCON->PINMODE3 = dir<<bitPosi;
			}

		break;

		case 2:

			if (bitPosi < 14 ) {
				bitPosi = bitPosi * 2;
				LPC_PINCON->PINMODE4 = dir<<bitPosi;
			}

		break;

		case 3:

			if (bitPosi == 25){
				LPC_PINCON->PINMODE7 = dir<<18;
			}else if (bitPosi == 26){
				LPC_PINCON->PINMODE7 = dir<<20;
			}

		break;

		case 4:
			if (bitPosi == 28){
				LPC_PINCON->PINMODE9 = dir<<24;
			}else if (bitPosi == 29){
				LPC_PINCON->PINMODE9 = dir<<26;
			}

	}
}

uint32_t GPIO::Read(uint32_t portNum, uint32_t bitPosi)
{
    uint32_t val;
    LPC_GPIO[portNum]->FIOMASK = ~(1<<bitPosi);
    val = LPC_GPIO[portNum]->FIOPIN;
    val = val >> bitPosi;
    return val;
}

