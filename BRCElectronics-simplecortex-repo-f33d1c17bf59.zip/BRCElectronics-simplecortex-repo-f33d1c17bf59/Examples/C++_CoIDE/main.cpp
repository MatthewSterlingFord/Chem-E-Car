#include "lpc17xx.h"
#include "lpc_types.h"
#include "gpio.h"
#include "timer.h"

GPIO led;

int main (void)
{

	led.Output(0, 22);
	init_timer(0, 10000);

	while(1)
	{
		led.On(0, 22);
		delayMs(0, 500);
		led.Off(0, 22);
		delayMs(0, 500);
	}
}
