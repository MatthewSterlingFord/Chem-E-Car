//Made by Eaglar

#include "lpc17xx.h"
#include "lpc_types.h"
#include "i2c.h"
#include "timer.h"
#include "gpio.h"

volatile uint32_t PORT_USED = 1;
_Bool var;
int main (void)
{

	GPIOSetDir(0,22,1);
	init_timer(0,10000);								//Initialize timer

	I2C1Init(0);										//Initialize I2C
	I2CMasterBuffer[PORT_USED][0] = 0b01001110;			//I2c address = 0x7e (write only)
	I2CWriteLength[PORT_USED] =  2;						//Write length 2 bytes
	I2CReadLength[PORT_USED] = 1;						//1 byte Read length

	while(1)											//infinity loop
	{

		I2CMasterBuffer[PORT_USED][1] = 0xff;			//Set all I2C-ports high
		I2CEngine( PORT_USED );							//Communicate with Ic

		delayMs(0,100);									//Delay

		I2CMasterBuffer[PORT_USED][1] = 0x00;			//Set all I2C-ports low
		I2CMasterBuffer[PORT_USED][2] = 0b01001111; 	//Command to Read
		I2CEngine( PORT_USED );							//Communicate with Ic

		delayMs(0,100);									//Delay

		var = (I2CSlaveBuffer[1][0]);					//
		GPIOSetValue(0,22,var);							//

	}

}
