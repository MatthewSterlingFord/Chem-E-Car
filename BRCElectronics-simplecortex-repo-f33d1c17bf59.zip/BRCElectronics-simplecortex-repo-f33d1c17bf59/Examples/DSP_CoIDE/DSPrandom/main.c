#include "LPC17xx.h"
#include "lpc_types.h"

#include "DSP/cr_dsplib.h"

/*****************************************************************************
** Function name:   main
**
** Descriptions:    Test bench for random number generator
**
** Parameters:	    None
**
** Returned value:  None
**
******************************************************************************/
int main(void)
{
	int i_Random = 1;
	int Buffer[100];
	volatile static int i = 0 ;

	for(i=0;i<100;i++)
	{
		i_Random = iF_RandomNumber(i_Random);
		Buffer[i] = i_Random;
	}

	variable = variable & 0xff000000;	//only keep the top 8 bits
	variable = variable >> 24;			//shift them 24 places to get an 8 bit variable

	while(1)
	{
		i++;
	}
}
