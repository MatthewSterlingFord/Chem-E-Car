#include "LPC17xx.h"
#include "lpc_types.h"
#include <math.h>
#include "DSP/cr_dsplib.h"

#define FRACTBITS 		14
#define SCALEFACTOR 	pow(2,FRACTBITS)
#define Amplitude 		1.0
#define TESTSIZE 		512

int pi_Output[TESTSIZE];

/*****************************************************************************
** Function name:   vF_dsplib_testbench_resonator
**
** Descriptions:    Test bench for resonator
**
** Parameters:	    None
**
** Returned value:  None
**
******************************************************************************/
void vF_dsplib_testbench_resonator(void)
{
	double pi = 4.0*atan(1.0);		//definition for pi (3.14)
	double Omega = 2*pi*1.0/100.0;  //Determines frequency

	//don't edit this
	tS_ResonatorStateCoeff S_ResonatorStateCoeff =
	{
		((2.0 * cos(Omega)) * SCALEFACTOR),
		0,
		((-Amplitude * sin(Omega)) * SCALEFACTOR)
	};

	vF_dspl_resonator(pi_Output, &S_ResonatorStateCoeff, 512); //actual command

}

/*****************************************************************************
** Function name:   main
**
** Descriptions:    Test bench for resonator
**
** Parameters:	    None
**
** Returned value:  None
**
******************************************************************************/
int main(void)
{
	vF_dsplib_testbench_resonator();
	//Sine wave can be found in the pi_Output array.

	// Enter an infinite loop, just incrementing a counter
	volatile static int i = 0;

	while(1)
	{
		i++;
	}
}

/*****************************************************************************
 **                            End Of File
 *****************************************************************************/
