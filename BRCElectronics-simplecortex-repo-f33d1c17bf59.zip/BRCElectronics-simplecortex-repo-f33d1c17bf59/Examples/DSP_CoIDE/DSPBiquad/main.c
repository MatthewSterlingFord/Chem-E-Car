#include "LPC17xx.h"
#include "lpc_types.h"
#include <math.h>
#include "DSP/cr_dsplib.h"

#define TESTSIZE 	128

int pi_Input[TESTSIZE];
int pi_Output[TESTSIZE];

/*****************************************************************************
** Function name:   vF_dsplib_testbench_biquad32
**
** Descriptions:    Test bench for biquad filter function
**
** Parameters:	    None
**
** Returned value:  None
**
******************************************************************************/
void vF_dsplib_testbench_biquad32(void)
{

	tS_biquad32_StateCoeff S_StateCoeff =
	{
		{0x2000,0,0x4000,0,0},
		{0,0}
	};

	pi_Input[0] = 0x10000000;

	vF_dspl_biquad32(pi_Output, pi_Input, &S_StateCoeff, TESTSIZE);

}

/*****************************************************************************
** Function name:   main
**
** Descriptions:    Test bench for biquad filter function
**
** Parameters:	    None
**
** Returned value:  None
**
******************************************************************************/
int main(void)
{
	vF_dsplib_testbench_biquad32();

	// Enter an infinite loop, just incrementing a counter
	volatile static int i = 0 ;

	while(1)
	{
		i++ ;
	}
}
