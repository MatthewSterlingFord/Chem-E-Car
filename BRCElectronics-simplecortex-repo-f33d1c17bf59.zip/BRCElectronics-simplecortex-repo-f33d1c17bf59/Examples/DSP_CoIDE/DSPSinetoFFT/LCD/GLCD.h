#define RST		26
#define WR		0
#define RD		24
#define RS		1
#define CS		23

void lowlevelinitIO(void);
void lowlevelwritedata(uint16_t data);
void ili9325Command(uint16_t command, uint16_t data);
void ili9325InitDisplay(void);
void ili9325WriteCmd(uint16_t command);
void ili9325WriteData(uint16_t data);
void ili9325Home(void);
void lcdFillRGB(uint16_t data);
uint16_t ili9325BGR2RGB(uint16_t color);
void ili9325SetCursor(uint16_t x, uint16_t y);
void lcdInit(void);
void lcdScroll(int16_t pixels, uint16_t fillColor);
void lcdDrawHLine(uint16_t x0, uint16_t x1, uint16_t y, uint16_t color);
void lcdDrawPixel(uint16_t x, uint16_t y, uint16_t color);
void lowlevelinitIOinput(void);
void lowlevelinitIOoutput(void);
uint16_t lowlevelreaddata(void);
uint16_t ili9325ReadData(void);
uint16_t ili9325Read(uint16_t addr);
void lcdTest(void);
void lcdDrawVLine(uint16_t y0, uint16_t y1, uint16_t x, uint16_t color);
void ili9325SetWindow(uint16_t x, uint16_t y, uint16_t x1, uint16_t y1);
void lcdReadTouch(uint32_t *xval, uint32_t *yval);
