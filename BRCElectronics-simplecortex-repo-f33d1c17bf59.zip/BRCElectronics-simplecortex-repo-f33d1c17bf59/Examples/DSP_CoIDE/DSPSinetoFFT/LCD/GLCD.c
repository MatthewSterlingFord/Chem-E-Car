#include "lpc17xx.h"
#include "lpc_types.h"
#include "GPIO.h"
#include "timer.h"
#include "GLCD.h"
#include "colors.h"

void lcdScroll(int16_t pixels, uint16_t fillColor)
{
  // Note: Not all ILI9325 imitations support HW vertical scrolling!
  // ST7781 - Not supported (ex. RFTechWorld 2.8" displays)
  // OTM3225A - Supported
  int16_t y = pixels;
  while (y < 0)
    y += 320;
  while (y >= 320)
    y -= 320;
  ili9325WriteCmd(0x6A);
  ili9325WriteData(y);
}

void lcdDrawHLine(uint16_t x0, uint16_t x1, uint16_t y, uint16_t color)
{
  // Allows for slightly better performance than setting individual pixels
  uint16_t x, pixels;

  if (x1 < x0)
  {
    // Switch x1 and x0
    x = x1;
    x1 = x0;
    x0 = x;
  }
  ili9325WriteCmd(0x0020); // GRAM Address Set (Horizontal Address) (R20h)
  ili9325WriteData(x0);
  ili9325WriteCmd(0x0021); // GRAM Address Set (Vertical Address) (R21h)
  ili9325WriteData(y);
  ili9325WriteCmd(0x0022);  // Write Data to GRAM (R22h)
  for (pixels = 0; pixels < x1 - x0 + 1; pixels++)
  {
    ili9325WriteData(color);
  }
}

void lcdDrawVLine(uint16_t y0, uint16_t y1, uint16_t x, uint16_t color)
{
	int pixels = 0;
	for (pixels = y0; pixels < y1; ++pixels)
	{
		lcdDrawPixel(x, pixels, color);
	}
}

void lcdDrawPixel(uint16_t x, uint16_t y, uint16_t color)
{
  ili9325WriteCmd(0x0020); // GRAM Address Set (Horizontal Address) (R20h)
  ili9325WriteData(x);
  ili9325WriteCmd(0x0021); // GRAM Address Set (Vertical Address) (R21h)
  ili9325WriteData(y);
  ili9325WriteCmd(0x0022);  // Write Data to GRAM (R22h)
  ili9325WriteData(color);
}

void lcdTest(void)
{
  uint32_t i,j;
  ili9325Home();

  for(i=0;i<320;i++)
  {
    for(j=0;j<240;j++)
    {
      if(i>279)ili9325WriteData(COLOR_WHITE);
      else if(i>239)ili9325WriteData(COLOR_BLUE);
      else if(i>199)ili9325WriteData(COLOR_GREEN);
      else if(i>159)ili9325WriteData(COLOR_CYAN);
      else if(i>119)ili9325WriteData(COLOR_RED);
      else if(i>79)ili9325WriteData(COLOR_MAGENTA);
      else if(i>39)ili9325WriteData(COLOR_YELLOW);
      else ili9325WriteData(COLOR_BLACK);
    }
  }
}

void lcdInit(void)
{
	ili9325InitDisplay();
	lcdFillRGB(0x0000);
}

void ili9325SetCursor(uint16_t x, uint16_t y)
{
  ili9325Command(0x0020, x);       // GRAM Address Set (Horizontal Address) (R20h)
  ili9325Command(0x0021, y);       // GRAM Address Set (Vertical Address) (R21h)
}

void lcdFillRGB(uint16_t data)
{
  unsigned int i;
  ili9325Home();

  uint32_t pixels = 320*240;
  for ( i=0; i < pixels; i++ )
  {
    ili9325WriteData(data);
  }
}

uint16_t ili9325BGR2RGB(uint16_t color)
{
  uint16_t r, g, b;

  b = (color>>0)  & 0x1f;
  g = (color>>5)  & 0x3f;
  r = (color>>11) & 0x1f;

  return( (b<<11) + (g<<5) + (r<<0) );
}

void ili9325Home(void)
{
  ili9325Command(0x0020, 0X0000);     // GRAM Address Set (Horizontal Address) (R20h)
  ili9325Command(0x0021, 0X0000);     // GRAM Address Set (Vertical Address) (R21h)
  ili9325WriteCmd(0x0022);            // Write Data to GRAM (R22h)
}


void ili9325InitDisplay(void)
{
	TimerInit(0, 5000);
	lowlevelinitIO();

	GPIOSetValue(0, CS, 1);
	GPIOSetValue(0, RS, 1);
	GPIOSetValue(0, WR, 1);

	GPIOSetValue(0, RST, 1);
	delayMs(0, 10);
	GPIOSetValue(0, RST, 0);
	delayMs(0, 10);
	GPIOSetValue(0, RST, 1);

	delayMs(0, 500);


	  ili9325Command(0x00FF, 0x0001);
	  ili9325Command(0x00F3, 0x0008);
	  ili9325WriteCmd(0x00F3);

	  ili9325Command(0x0001, 0x0100);     // Driver Output Control Register (R01h)
	  ili9325Command(0x0002, 0x0700);     // LCD Driving Waveform Control (R02h)
	  ili9325Command(0x0003, 0x1030);     // Entry Mode (R03h)
	  ili9325Command(0x0008, 0x0302);
	  ili9325Command(0x0009, 0x0000);
	  ili9325Command(0x0010, 0x0000);     // Power Control 1 (R10h)
	  ili9325Command(0x0011, 0x0007);     // Power Control 2 (R11h)
	  ili9325Command(0x0012, 0x0000);     // Power Control 3 (R12h)
	  ili9325Command(0x0013, 0x0000);     // Power Control 4 (R13h)
	  delayMs(0, 200);
	  ili9325Command(0x0010, 0x1690);     // Power Control 1 (R10h)
	  delayMs(0, 50);
	  ili9325Command(0x0011, 0x0227);     // Power Control 2 (R11h)
	  delayMs(0, 50);
	  ili9325Command(0x0012, 0x000D);     // Power Control 3 (R12h)
	  ili9325Command(0x0013, 0x1200);     // Power Control 4 (R13h)
	  ili9325Command(0x0029, 0x000A);     // NVM read data 2 (R29h)
	  delayMs(0, 50);
	  ili9325Command(0x0030, 0x0000);     // Gamma Control 1
	  ili9325Command(0x0031, 0x0000);     // Gamma Control 2
	  ili9325Command(0x0032, 0x0000);     // Gamma Control 3
	  ili9325Command(0x0035, 0x0206);     // Gamma Control 6
	  ili9325Command(0x0036, 0x0808);     // Gamma Control 7
	  ili9325Command(0x0037, 0x0007);     // Gamma Control 8
	  ili9325Command(0x0038, 0x0201);     // Gamma Control 9
	  ili9325Command(0x0039, 0x0000);     // Gamma Control 10
	  ili9325Command(0x003C, 0x0000);     // Gamma Control 13
	  ili9325Command(0x003D, 0x0000);     // Gamma Control 14
	  ili9325Command(0x0050, 0x0000);     // Window Horizontal RAM Address Start (R50h)
	  ili9325Command(0x0051, 0x00EF);     // Window Horizontal RAM Address End (R51h)
	  ili9325Command(0x0052, 0X0000);     // Window Vertical RAM Address Start (R52h)
	  ili9325Command(0x0053, 0x013F);     // Window Vertical RAM Address End (R53h)
	  ili9325Command(0x0060, 0xa700);     // Driver Output Control (R60h)
	  ili9325Command(0x0061, 0x0003);     // Driver Output Control (R61h)
	  ili9325Command(0x0090, 0X0010);     // Panel Interface Control 1 (R90h)
	  ili9325Command(0x0092, 0X0000);
	  // Display On
	  ili9325Command(0x0007, 0x0133);     // Display Control (R07h)
	  delayMs(0, 50);
	  ili9325WriteCmd(0x0022);

}

void ili9325WriteCmd(uint16_t command)
{

	LPC_GPIO0->FIOCLR = 0b100000000000000000000010;	//Clear CS, RS
	lowlevelwritedata(command);
//	LPC_GPIO0->FIOSET = 0b100000000000000000000001; //set CS, WR

}

void ili9325WriteData(uint16_t data)
{
	LPC_GPIO0->FIOSET = 0b11;						//Set RS, WR
	LPC_GPIO0->FIOCLR = (0b1 << 23);				//Clear CS
	lowlevelwritedata(data);
	LPC_GPIO0->FIOSET = 0b100000000000000000000001;

}

void ili9325Command(uint16_t command, uint16_t data)
{
  // Provided for convenience sake ... shouldn't be used
  // in critical sections since it adds an extra
  // branch, etc.
  ili9325WriteCmd(command);
	LPC_GPIO0->FIOSET = 0b100000000000000000000001; //set CS, WR
  ili9325WriteData(data);
}


void lowlevelwritedata(uint16_t data)
{
	//first byte
	if (data & 256)
	{
		LPC_GPIO0->FIOSET = (1 << 3);
	}
	else
	{
		LPC_GPIO0->FIOCLR = (1 << 3);
	}
	if (data & 512)
	{
		LPC_GPIO0->FIOSET = (1 << 2);
	}
	else
	{
		LPC_GPIO0->FIOCLR = (1 << 2);
	}
	if (data & 1024)
	{
		LPC_GPIO0->FIOSET = (1 << 4);
	}
	else
	{
		LPC_GPIO0->FIOCLR = (1 << 4);
	}
	if (data & 2048)
	{
		LPC_GPIO2->FIOSET = (1 << 0);
	}
	else
	{
		LPC_GPIO2->FIOCLR = (1 << 0);
	}
	if (data & 4096)
	{
		LPC_GPIO0->FIOSET = (1 << 5);
	}
	else
	{
		LPC_GPIO0->FIOCLR = (1 << 5);
	}
	if (data & 8192)
	{
		LPC_GPIO2->FIOSET = (1 << 2);
	}
	else
	{
		LPC_GPIO2->FIOCLR = (1 << 2);
	}
	if (data & 16384)
	{
		LPC_GPIO2->FIOSET = (1 << 1);
	}
	else
	{
		LPC_GPIO2->FIOCLR = (1 << 1);
	}
	if (data & 32768)
	{
		LPC_GPIO0->FIOSET = (1 << 6);
	}
	else
	{
		LPC_GPIO0->FIOCLR = (1 << 6);
	}

//	GPIOSetValue(0, WR, 0);
	LPC_GPIO0->FIOCLR = (1<<WR);
	GPIOSetValue(0, WR, 1);
//	LPC_GPIO0->FIOSET = (1<<WR);

	//second byte
	if (data & 1)
	{
		LPC_GPIO0->FIOSET = (1 << 3);
	}
	else
	{
		LPC_GPIO0->FIOCLR = (1 << 3);
	}
	if (data & 2)
	{
		LPC_GPIO0->FIOSET = (1 << 2);
	}
	else
	{
		LPC_GPIO0->FIOCLR = (1 << 2);
	}
	if (data & 4)
	{
		LPC_GPIO0->FIOSET = (1 << 4);
	}
	else
	{
		LPC_GPIO0->FIOCLR = (1 << 4);
	}
	if (data & 8)
	{
		LPC_GPIO2->FIOSET = (1 << 0);
	}
	else
	{
		LPC_GPIO2->FIOCLR = (1 << 0);
	}
	if (data & 16)
	{
		LPC_GPIO0->FIOSET = (1 << 5);
	}
	else
	{
		LPC_GPIO0->FIOCLR = (1 << 5);
	}
	if (data & 32)
	{
		LPC_GPIO2->FIOSET = (1 << 2);
	}
	else
	{
		LPC_GPIO2->FIOCLR = (1 << 2);
	}
	if (data & 64)
	{
		LPC_GPIO2->FIOSET = (1 << 1);
	}
	else
	{
		LPC_GPIO2->FIOCLR = (1 << 1);
	}
	if (data & 128)
	{
		LPC_GPIO0->FIOSET = (1 << 6);
	}
	else
	{
		LPC_GPIO0->FIOCLR = (1 << 6);
	}

	GPIOSetValue(0, WR, 0);
}

void ili9325SetWindow(uint16_t x, uint16_t y, uint16_t x1, uint16_t y1)
{
  ili9325Command(0x0050, x);       // Window Horizontal RAM Address Start (R50h)
  ili9325Command(0x0051, x1);      // Window Horizontal RAM Address End (R51h)
  ili9325Command(0x0052, y);       // Window Vertical RAM Address Start (R52h) )
  ili9325Command(0x0053, y1);      // Window Vertical RAM Address End (R53h)
}

void lowlevelinitIO(void)
{
	GPIOSetDir(0, RST, 1);
	GPIOSetDir(0, WR, 1);
	GPIOSetDir(0, RS, 1);
	GPIOSetDir(0, CS, 1);
	GPIOSetDir(0, RD, 1);

	GPIOSetDir(0, 3, 1);	//data0
	GPIOSetDir(0, 2, 1);	//data1
	GPIOSetDir(0, 4, 1);	//data2
	GPIOSetDir(2, 0, 1);	//data3
	GPIOSetDir(0, 5, 1);	//data4
	GPIOSetDir(2, 2, 1);	//data5
	GPIOSetDir(2, 1, 1);	//data6
	GPIOSetDir(0, 6, 1);	//data7

	GPIOSetValue(0, 3, 0);	//data0
	GPIOSetValue(0, 2, 0);	//data1
	GPIOSetValue(0, 4, 0);	//data2
	GPIOSetValue(2, 0, 0);	//data3
	GPIOSetValue(0, 5, 0);	//data4
	GPIOSetValue(2, 2, 0);	//data5
	GPIOSetValue(2, 1, 0);	//data6
	GPIOSetValue(0, 6, 0);	//data7

	GPIOSetValue(0, RD, 1);	//data7
}

void lowlevelinitIOoutput(void)
{
	GPIOSetDir(0, 3, 1);	//data0
	GPIOSetDir(0, 2, 1);	//data1
	GPIOSetDir(0, 4, 1);	//data2
	GPIOSetDir(2, 0, 1);	//data3
	GPIOSetDir(0, 5, 1);	//data4
	GPIOSetDir(2, 2, 1);	//data5
	GPIOSetDir(2, 1, 1);	//data6
	GPIOSetDir(0, 6, 1);	//data7

}

void lowlevelinitIOinput(void)
{
	GPIOSetDir(0, 3, 0);	//data0
	GPIOSetDir(0, 2, 0);	//data1
	GPIOSetDir(0, 4, 0);	//data2
	GPIOSetDir(2, 0, 0);	//data3
	GPIOSetDir(0, 5, 0);	//data4
	GPIOSetDir(2, 2, 0);	//data5
	GPIOSetDir(2, 1, 0);	//data6
	GPIOSetDir(0, 6, 0);	//data7

}


uint16_t ili9325Read(uint16_t addr)
{
  ili9325WriteCmd(addr);
  return ili9325ReadData();
}

uint16_t ili9325ReadData(void)
{
  uint16_t d;

  GPIOSetValue(0, CS, 0);
  GPIOSetValue(0, RS, 1);
  GPIOSetValue(0, RD, 1);
  GPIOSetValue(0, WR, 1);

  // set inputs
  lowlevelinitIOinput();
  d = lowlevelreaddata();
  GPIOSetValue(0, CS, 1);
  lowlevelinitIO();
  return d;
}

uint16_t lowlevelreaddata(void)
{

	uint16_t d = 0;
	//first byte
	d += 256 * GPIOGetValue(0, 3);
	d += 512 * GPIOGetValue(0, 2);
	d += 1024 * GPIOGetValue(0, 4);
	d += 2048 * GPIOGetValue(2, 0);
	d += 4096 * GPIOGetValue(0, 5);
	d += 8192 * GPIOGetValue(2, 2);
	d += 16384 * GPIOGetValue(2, 1);
	d += 32768 * GPIOGetValue(0, 6);
	GPIOSetValue(0, RD, 0);
	GPIOSetValue(0, RD, 1);

	//second byte
	d += 1 * GPIOGetValue(0, 3);
	d += 2 * GPIOGetValue(0, 2);
	d += 4 * GPIOGetValue(0, 4);
	d += 8 * GPIOGetValue(2, 0);
	d += 16 * GPIOGetValue(0, 5);
	d += 32 * GPIOGetValue(2, 2);
	d += 64 * GPIOGetValue(2, 1);
	d += 128 * GPIOGetValue(0, 6);
	GPIOSetValue(0, RD, 0);
	GPIOSetValue(0, RD, 1);
	return d;
}

void lcdReadTouch(uint32_t *xval, uint32_t *yval)
{
	GPIOSetDir(2, 4, 1);	//CS
	GPIOSetDir(0, 25, 1);	//CLK
	GPIOSetDir(0, 7, 0);	//DIN
	GPIOSetDir(0, 26, 1);	//DOUT
	uint8_t i;
	uint8_t datatosend = 0x9;	//command to read Y axis with 12 bits
	uint32_t datatoreadY = 0;
	uint32_t datatoreadX = 0;

	//Read Y axis
	GPIOSetValue(2, 4, 0);

	for (i = 0; i < 24; ++i)
	{
		uint32_t delaycount;
		if(i < 8)
		{
		GPIOSetValue(0, 26, ((datatosend >> i) & 1) );	//first 8 clocks send data
		}

		if((i >= 9) && (i <= 20))
		{
			datatoreadY = datatoreadY << 1;
			datatoreadY += GPIOGetValue(0, 7);
		}

		GPIOSetValue(0, 25, 1);		//clock high
		for (delaycount = 0; delaycount < 80; ++delaycount) 	//small delay
		{
			asm("mov r0,r0");
		}

		GPIOSetValue(0, 25, 0);		//clock low
		for (delaycount = 0; delaycount < 100; ++delaycount) 	//small delay
		{
			asm("mov r0,r0");
		}

	}
	GPIOSetValue(2, 4, 1);

	//read X axis
	datatosend = 0xB;
	GPIOSetValue(2, 4, 0);

	for (i = 0; i < 24; ++i)
	{
		uint32_t delaycount;
		if(i < 8)
		{
		GPIOSetValue(0, 26, ((datatosend >> i) & 1) );	//first 8 clocks send data
		}

		if((i >= 9) && (i <= 20))
		{
			datatoreadX = datatoreadX << 1;
			datatoreadX += GPIOGetValue(0, 7);
		}

		GPIOSetValue(0, 25, 1);		//clock high
		for (delaycount = 0; delaycount < 80; ++delaycount) 	//small delay
		{
			asm("mov r0,r0");
		}

		GPIOSetValue(0, 25, 0);		//clock low
		for (delaycount = 0; delaycount < 100; ++delaycount) 	//small delay
		{
			asm("mov r0,r0");
		}

	}
	GPIOSetValue(2, 4, 1);

	if(datatoreadY >= 4094)
	{
		datatoreadX = 4095;
	}

	*xval = ((4095 - datatoreadX) / 17);
	*yval = ((4095 - datatoreadY) / 13);
	return;
}
