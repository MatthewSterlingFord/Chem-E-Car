#include "LPC17xx.h"
#include "lpc_types.h"
#include <math.h>
#include "DSP/cr_dsplib.h"
#include "float.h"
#include <string.h>
#include <stdlib.h>
#include "GPIO.h"
#include "timer.h"
#include "colors.h"
#include "drawing.h"
#include "GLCD.h"

//A small program to demonstrate the resonate and FFT functions of the DSP library.
//It generates 2 sines, one sine has a 10 times higher frequency then the other
//The FFT does it's job and then shows the result on the LCD screen.
//As the FFT gives a positive and negative result the negative part is ignored to make the graph look a bit better

#define TESTSIZE 		1024
#define FRACTBITS 		14
#define SCALEFACTOR 	pow(2,FRACTBITS)
double Amplitude = 1.0;
int pi_Output[TESTSIZE];
int pi_Output2[TESTSIZE];
short pi_Output3[TESTSIZE];
short pi_Output4[TESTSIZE * 2];
int n;
int e;


int main(void)
{
	//init the LCD
	lcdInit();
	lcdFillRGB(COLOR_LIGHTGRAY);

	//init the variables for the fist sine and generate it
	double pi = 4.0*atan(1.0);
	double Omega = 2*pi*0.5/100.0;
	tS_ResonatorStateCoeff S_ResonatorStateCoeff =
	{
		((2.0 * cos(Omega)) * SCALEFACTOR),
		0,
		((-Amplitude * sin(Omega)) * SCALEFACTOR)
	};

	vF_dspl_resonator(pi_Output2, &S_ResonatorStateCoeff, 256);

	//Init them for the second sine, higher frequency and lower amplitude and generate the sine
	Amplitude = 0.3;
	Omega = 2*pi*5/100.0;
	S_ResonatorStateCoeff.i_Coeff_a1 = ((2.0 * cos(Omega)) * SCALEFACTOR);
	S_ResonatorStateCoeff.i_yn_1 = 0;
	S_ResonatorStateCoeff.i_yn_2 = ((-Amplitude * sin(Omega)) * SCALEFACTOR);

	//Combine the sines, just add them to each other
	vF_dspl_resonator(pi_Output, &S_ResonatorStateCoeff, 256);
	uint32_t n;
	for (n = 0; n < TESTSIZE; ++n)
	{
		pi_Output3[n] = pi_Output[n] + pi_Output2[n];
	}

	//FFT time and send it to the LCD.
	vF_dspl_fftR4b16N1024(pi_Output4, pi_Output3);
	int count = 0;
	for (n = 321; n > 1; --n)		//we got 1024 points of data but just 320 pixels of resolution, need to make concessions.
	{
		count += 1;
		int valuefft;
		int valuelcd;
		valuefft = pi_Output4[count];
		if (valuefft <= 0)
		{
			valuefft = 0;
		}
		valuelcd = valuefft / 10;
		drawLine(5, n, valuelcd+5, n, COLOR_BLUE);
	}


	//All done now, go in an infinite loop
	volatile static int i = 0 ;
	while(1)
	{
		i++ ;
	}
}
