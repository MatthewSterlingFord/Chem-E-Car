#include "lpc17xx.h"
#include "lpc_types.h"
#include "gpio.h"
#include "timer.h"


int main (void)
{

	GPIOSetDir(1, 25, OUTPUT);			//declare led 1.27
	GPIOSetDir(1, 27, INPUT);			//declare button 1.17
	GPIOSetPull(1, 27, PULLUP);			//pull-up resistor for button 1.17
	uint32_t var;						//declare variable

	while(1)
	{
		var = GPIOGetValue(1, 27);		// read the button value
		if (var == 0)					// the button is pushed
		{
			GPIOSetValue(1, 25, HIGH); 	//led high
		}
		else							// the button is not pushed
		{
			GPIOSetValue(1, 25, LOW); 	//led low
		}
	}
}
